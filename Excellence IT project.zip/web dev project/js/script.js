function incapp(){
    open("https://incapp.in/")
}

function closefu(){
    close();
}